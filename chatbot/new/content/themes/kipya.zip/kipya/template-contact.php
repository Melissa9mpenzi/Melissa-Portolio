<?php /* Template Name: Alternative Contact Page Template */ get_header(); 
    include get_template_directory() . '/inc/menus/menu.php'; 
    
    // Handle form submission (same as before)
    if (isset($_POST['contact_submitted'])) {
        $name = sanitize_text_field($_POST['contact_name']);
        $email = sanitize_email($_POST['contact_email']);
        $phone = sanitize_text_field($_POST['contact_phone']);
        $subject = sanitize_text_field($_POST['contact_subject']);
        $message = sanitize_textarea_field($_POST['contact_message']);
        
        $post_content = "Name: $name\n";
        $post_content .= "Email: $email\n";
        $post_content .= "Phone: $phone\n";
        $post_content .= "Subject: $subject\n\n";
        $post_content .= "Message:\n$message";
        
        $contact_post = array(
            'post_title' => 'New Contact: ' . $name . ' - ' . $subject,
            'post_content' => $post_content,
            'post_status' => 'private',
            'post_type' => 'contact_submission',
        );
        
        $post_id = wp_insert_post($contact_post);
        
        if ($post_id) {
            $submission_success = true;
        }
    }
?>

<main role="main">
    
<?php 
$backgroundImg = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full'); 
?>
    

<section class="hero-section" style="background-image: url('<?php echo esc_url($backgroundImg[0]); ?>');" data-aos="fade-in" data-aos-duration="1500">

    <div class="hero-overlay">
        <div class="hero-content">
            <h1 style="font-weight: 700 !important;" class="hero-title" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="200"><?php the_title(); ?></h1>
            <div class="hero-breadcrumb" data-aos="fade-up" data-aos-duration="800" data-aos-delay="400">
                <a style="color: #fff;" href="<?php echo esc_url(home_url()); ?>">Home</a> / <?php the_title(); ?>
            </div>
        </div>
    </div>

</section>

<div class="alt-contact-container" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
    <?php if (have_posts()): while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> data-aos="fade-up" data-aos-duration="600" data-aos-delay="300">
            <?php 
            // Add AOS to content
            $content = get_the_content();
            $content = preg_replace('/<h([2-4])([^>]*)>/', '<h$1$2 data-aos="fade-up" data-aos-duration="600" data-aos-delay="300">', $content);
            echo apply_filters('the_content', $content);
            ?>
            
            <?php if (isset($submission_success) && $submission_success): ?>
            <div class="alt-contact-success-popup" data-aos="zoom-in" data-aos-duration="800" data-aos-delay="200">
                <div class="alt-success-content">
                    <div class="alt-checkmark" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="300">
                        <svg viewBox="0 0 52 52">
                            <circle cx="26" cy="26" r="25" fill="var(--kpy-primary)"/>
                            <path fill="none" stroke="#fff" stroke-width="4" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                        </svg>
                    </div>
                    <h3 data-aos="fade-up" data-aos-duration="600" data-aos-delay="400">Message Sent!</h3>
                    <p data-aos="fade-up" data-aos-duration="600" data-aos-delay="500">We've received your message and will respond soon. God bless you.</p>
                    <button class="alt-close-popup" data-aos="fade-up" data-aos-duration="600" data-aos-delay="600">Close</button>
                </div>
            </div>
            <?php endif; ?>
            
        </article>
    <?php endwhile; endif; ?>
    
    <!-- New Contact Layout with Map -->
    <div class="alt-contact-layout">

    <!-- TOP ROW : INFO + FORM -->
    <div class="alt-contact-top">

        <!-- Contact Info Column -->
        <div class="alt-contact-info-col" data-aos="fade-right" data-aos-duration="800" data-aos-delay="200">
            <div class="alt-contact-info-card">
                <h3 class="alt-contact-info-title" data-aos="fade-down" data-aos-duration="600" data-aos-delay="300">Our Information</h3>

                <div class="alt-contact-info-item" data-aos="fade-up" data-aos-duration="600" data-aos-delay="400">
                    <div class="alt-contact-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="450">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="var(--kpy-primary)">
                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                        </svg>
                    </div>
                    <div class="alt-contact-text">
                        <h4 data-aos="fade-up" data-aos-duration="500" data-aos-delay="500">Location</h4>
                        <p data-aos="fade-up" data-aos-duration="500" data-aos-delay="550">Second Floor, Suite 2.8 <br>Coffee House,<br>Plot 35 Jinja Road<br>P. O. Box 7267 Kampala Uganda</p>
                    </div>
                </div>

                <div class="alt-contact-info-item" data-aos="fade-up" data-aos-duration="600" data-aos-delay="500">
                    <div class="alt-contact-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="550">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="var(--kpy-primary)">
                            <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                        </svg>
                    </div>
                    <div class="alt-contact-text">
                        <h4 data-aos="fade-up" data-aos-duration="500" data-aos-delay="600">Email Us</h4>
                        <p data-aos="fade-up" data-aos-duration="500" data-aos-delay="650">info@iwcauganda.org</p>
                    </div>
                </div>

                <div class="alt-contact-info-item" data-aos="fade-up" data-aos-duration="600" data-aos-delay="600">
                    <div class="alt-contact-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="650">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="var(--kpy-primary)">
                            <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/>
                        </svg>
                    </div>
                    <div class="alt-contact-text">
                        <h4 data-aos="fade-up" data-aos-duration="500" data-aos-delay="700">Call Us</h4>
                        <p data-aos="fade-up" data-aos-duration="500" data-aos-delay="750"> +256 754 812 897</p>
                    </div>
                </div>

                <div class="alt-contact-hours" data-aos="fade-up" data-aos-duration="600" data-aos-delay="700">
                    <h4 data-aos="fade-up" data-aos-duration="500" data-aos-delay="750">Available</h4>
                    <p data-aos="fade-up" data-aos-duration="500" data-aos-delay="800">
                        Monday - Friday: 8:00 AM - 5:00 PM<br>
                        Saturday: 9:00 AM - 2:00 PM<br>
                        Sunday: Closed (Worship Day)
                    </p>
                </div>
            </div>

            <div class="alt-contact-social" data-aos="fade-up" data-aos-duration="600" data-aos-delay="800">
                <h4 data-aos="fade-up" data-aos-duration="500" data-aos-delay="850">Connect With Us</h4>
                <div class="alt-social-icons">
                    <a href="#" class="alt-social-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="900"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="alt-social-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="950"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="alt-social-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="1000"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="alt-social-icon" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="1050"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>

        <!-- Contact Form Column -->
        <div class="alt-contact-form-col" data-aos="fade-left" data-aos-duration="800" data-aos-delay="300">
            <div class="alt-contact-form-card">
                <h3 class="alt-form-title" data-aos="fade-down" data-aos-duration="600" data-aos-delay="400">Send Us a Message</h3>
                <p class="alt-form-subtitle" data-aos="fade-up" data-aos-duration="600" data-aos-delay="450">Fill out the form below and we'll respond as soon as possible.</p>

                <form id="alt-contact-form" method="post" class="alt-contact-form">
                    <div class="alt-form-group" data-aos="fade-up" data-aos-duration="600" data-aos-delay="500">
                        <label>Your Name <span>*</span></label>
                        <input type="text" name="contact_name" required>
                    </div>

                    <div class="alt-form-row">
                        <div class="alt-form-group alt-form-half" data-aos="fade-up" data-aos-duration="600" data-aos-delay="550">
                            <label>Email Address <span>*</span></label>
                            <input type="email" name="contact_email" required>
                        </div>
                        <div class="alt-form-group alt-form-half" data-aos="fade-up" data-aos-duration="600" data-aos-delay="600">
                            <label>Phone Number</label>
                            <input type="tel" name="contact_phone">
                        </div>
                    </div>

                    <div class="alt-form-group" data-aos="fade-up" data-aos-duration="600" data-aos-delay="650">
                        <label>Subject <span>*</span></label>
                        <input type="text" name="contact_subject" required>
                    </div>

                    <div class="alt-form-group" data-aos="fade-up" data-aos-duration="600" data-aos-delay="700">
                        <label>Your Message <span>*</span></label>
                        <textarea name="contact_message" rows="6" required></textarea>
                    </div>

                    <div class="alt-form-submit" data-aos="fade-up" data-aos-duration="600" data-aos-delay="750">
                        <button type="submit" name="contact_submitted" class="alt-submit-btn" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="800">
                            Send Message
                        </button>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <!-- BOTTOM ROW : MAP -->
    <div class="alt-contact-map-col" data-aos="fade-up" data-aos-duration="800" data-aos-delay="400">
        <div class="alt-contact-map-card">
            <h3 class="alt-map-title" data-aos="fade-down" data-aos-duration="600" data-aos-delay="450">Find Us</h3>

            <div class="alt-map-container" data-aos="zoom-in" data-aos-duration="800" data-aos-delay="500">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63836.12997347918!2d32.52513753125!3d0.31473790000000257!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbc785f91abd5%3A0xb3c9a0c6a450e1ce!2sIWCA%20UGANDA%20CHAPTER!5e0!3m2!1sen!2sug!4v1769718115587!5m2!1sen!2sug" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

            <div class="alt-map-directions" data-aos="fade-up" data-aos-duration="600" data-aos-delay="600">
                <a href="https://maps.google.com?daddr=123+Faith+Avenue+Kampala" target="_blank" class="alt-directions-btn" data-aos="zoom-in" data-aos-duration="600" data-aos-delay="650">
                    Get Directions
                </a>
            </div>
        </div>
    </div>

</div>

</div>

</main>

<script>
jQuery(document).ready(function($) {
    // Show success popup if submission was successful
    <?php if (isset($submission_success) && $submission_success): ?>
        $('.alt-contact-success-popup').addClass('active');
    <?php endif; ?>
    
    // Close popup handler
    $('.alt-close-popup').on('click', function() {
        $('.alt-contact-success-popup').removeClass('active');
    });
});
</script>

<?php get_footer(); ?>