<?php
/**
 * Template Name: App - Web Design
 *
 * @package Kipya
 */

get_header();
include get_template_directory() . '/inc/menus/menu.php';

if (function_exists('kipya_render_service_template')) {
    kipya_render_service_template(array(
        'family'            => 'web',
        'eyebrow'           => 'Websites by LWEGATECH',
        'hero_title'        => 'Professional Website Design',
        'hero_subtitle'     => 'We bring your ideas to life with thoughtful design and smart functionality.',
        'gif_url'           => 'https://media.giphy.com/media/3o7aD2saalBwwftBIY/giphy.gif', // Keeps hero generic animated
        'intro_title'       => 'Tailored For Your Business',
        'intro_text'        => "Whether you're starting fresh or redesigning, our team ensures your website looks great, loads fast, and helps you achieve more online. We offer flexible web packages tailored exactly to your needs.",
        'highlights'        => array(
            array('title' => 'Responsive Design', 'text' => 'Flawless experiences on mobile, tablet, and desktop securely.', 'icon' => 'fa-solid fa-mobile-screen'),
            array('title' => 'Speed Optimized', 'text' => 'Fast loading times to improve user retention and SEO ranking.', 'icon' => 'fa-solid fa-gauge-high'),
            array('title' => 'Custom CMS', 'text' => 'Easy-to-use backend so you can manage your content seamlessly without coding.', 'icon' => 'fa-solid fa-layer-group'),
        ),
        'packages'          => array(
            array(
                'title'    => 'Startup Package',
                'price'    => '',
                'desc'     => 'Perfect for small businesses starting their digital journey.',
                'features' => array(
                    '100% Custom Design',
                    'Mobile-Optimized & Lightning Fast',
                    'Essential & Responsive Pages',
                    'SEO-Ready Structure',
                    'High-Performance Graphics',
                    'Social Media Integration',
                    'Simple Image Gallery',
                    'Free Website Deployment',
                    '30 days of Free Support'
                )
            ),
            array(
                'title'    => 'Business package',
                'price'    => '',
                'desc'     => 'Advanced features for growing companies needing dynamic content.',
                'features' => array(
                    'Your Choice of CMS ( WordPress/Joomla)',
                    'Custom Website Development',
                    'Mobile-Optimized & Accessible Design',
                    'SEO-Ready Architecture',
                    'Dynamic Content Sections (News & Events)',
                    'File Downloads/Publications Hub',
                    'Advanced Media Galleries',
                    'Social Media Integration',
                    'User Online Training + Manual',
                    '90 Days Free Support'
                )
            ),
            array(
                'title'    => 'Corporate Package',
                'price'    => '',
                'desc'     => 'Empowering Your Business with Tailored Web Solutions. Our Corporate package is a highly tailored solution, fully customized based on the client\'s specific requirements. From e-commerce websites to fully custom content management systems, we develop client-centric features that empower your business and elevate your online presence.',
                'features' => array(
                    'Your Choice of CMS ( WordPress/Joomla/Custom)',
                    'E-commerce Solutions',
                    'API Integrations',
                    'Forum or Blog',
                    'Directory component',
                    'Google Analytics',
                    'ALL Business Web features',
                    'User Training + Manual',
                    '120 Days Free Support'
                )
            )
        ),
        'faqs'              => array(
            array('q' => 'Do you provide domain registration and hosting?', 'a' => 'Yes, every layout package can be bundled with reliable hosting services and custom domain registration handled entirely by our infrastructure team.'),
            array('q' => 'Will my website be mobile-responsive?', 'a' => '100% yes. All modern architectures deployed by our team follow "Mobile-First" principles, ensuring perfect rendering on phones and tablets.'),
            array('q' => 'Can I update the website content myself?', 'a' => 'Yes, we implement powerful Content Management Systems (CMS) like WordPress allowing non-technical staff to easily manage blogs and media.'),
            array('q' => 'How long does a typical redesign take?', 'a' => 'A standard business or startup site typically takes between 2 to 4 weeks depending entirely on client feedback and content availability.'),
            array('q' => 'Do you provide e-commerce implementation?', 'a' => 'Yes! The Corporate package natively includes custom e-commerce deployment complete with payment gateway integration securely designed for high conversion.'),
            array('q' => 'Are SEO best practices included?', 'a' => 'Absolutely. We code with Semantic HTML5 and adhere rigidly to Google Lighthouse standards, guaranteeing an SEO-ready structure right from launch.'),
            array('q' => 'Will I own the code and the domain?', 'a' => '100%. Upon completion and final installment, you retain complete legal digital ownership of intellectual property and domains.'),
            array('q' => 'Can you integrate our existing CRM?', 'a' => 'Yes. Corporate packages fully support rich API integrations spanning HubSpot, Salesforce, and custom endpoints.'),
            array('q' => 'Do we get training on how to use the CMS?', 'a' => 'Yes. Both Business and Corporate packages feature live User Training sessions alongside comprehensive Digital Manuals for your staff.'),
            array('q' => 'What happens after the free support period expires?', 'a' => 'We offer continuous, hassle-free Website Maintenance packages to protect and update your asset on a monthly or quarterly basis.'),
        ),
        'deliverables'      => array(
            '100% Custom Design & Layout',
            'Social Media & Google Analytics Integration',
            'Full Content Management System Access',
            'Security Configurations',
            'User Manual & Team Training',
        ),
        'cta_title'         => 'Ready to build your digital presence?',
        'cta_text'          => 'Partner with Lwegatech to create a fast, converting, and professional website.',
        'cta_primary_label' => 'Start Your Project',
        'cta_primary_url'   => home_url('/contact-us/'),
        'cta_secondary_label' => 'View Our Portfolio',
        'cta_secondary_url' => home_url('/our-work/'),
    ));
}

get_footer();
