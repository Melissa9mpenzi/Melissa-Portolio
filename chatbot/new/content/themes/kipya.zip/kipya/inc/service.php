<?php
/**
 * Services Grid Shortcode
 *
 * Displays pages with a given file_category as a services grid.
 * The hero card (top-left) is a looping, muted, autoplay video.
 *
 * Usage:
 *   [kpy_services_grid
 *       category="your_category_slug"
 *       video_url="https://example.com/path/to/video.mp4"
 *       title="Our Services"
 *       subtitle="We work with enterprises, organizations, and businesses from various industries."
 *   ]
 *
 * Parameters:
 *   category  (string)  – The file_category taxonomy term slug to query. Default: "service"
 *   video_url (string)  – Absolute URL to the MP4 video for the hero card. Required.
 *   title     (string)  – Section heading. Default: "Our Services"
 *   subtitle  (string)  – Section sub-heading. Default: ""
 *   posts_per_page (int)– Max pages to show (excluding hero). Default: 6
 */

if ( ! function_exists( 'kpy_services_grid_shortcode' ) ) {

    function kpy_services_grid_shortcode( $atts ) {

        $atts = shortcode_atts( [
            'category'      => 'service',
            'video_url'     => '',
            'title'         => 'Our Services',
            'subtitle'      => 'We work with enterprises, organizations, and businesses from various industries.',
            'posts_per_page'=> 6,
        ], $atts, 'kpy_services_grid' );

       $query = new WP_Query( [
            'post_type'      => 'page',
            'posts_per_page' => intval( $atts['posts_per_page'] ),
            'tax_query'      => [
                [
                    'taxonomy' => 'page_category',
                    'field'    => 'slug',
                    'terms'    => array( sanitize_title( $atts['category'] ) ),
                ],
            ],
        ] );

        $pages = $query->posts;

        // Unique ID so multiple shortcodes on one page don't clash
        $uid = 'kpy-sg-' . uniqid();

        // Enqueue Font Awesome if not already loaded
        wp_enqueue_style( 'font-awesome-6', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css', array(), '6.4.2' );

        ob_start();
        ?>
        <div class="kpy-sg-wrapper" id="<?php echo esc_attr( $uid ); ?>">

            <!-- ── Section Header with "Our" in Red, "Services" in White ── -->
            <div class="kpy-sg-header">
                <div class="kpy-sg-title-container">
                <div class="kpy-sg-title-bg" aria-hidden="true">
                    What We Do
                </div>

                <!-- MAIN TITLE -->
                <h2 class="kpy-sg-title">
                    <span class="kpy-sg-title-red">Our</span>
                    <span class="kpy-sg-title-white">Services</span>
                </h2>

            </div>
                <?php if ( $atts['subtitle'] ) : ?>
                    <p class="kpy-sg-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
                <?php endif; ?>
            </div>

            <!-- ── Grid 4x3 with spacing ── -->
            <div class="kpy-sg-grid">

                <!-- ── Hero Video Card (3 columns × 2 rows) - CLEAN, NO OVERLAY TEXT ── -->
                <div class="kpy-sg-card kpy-sg-card--hero">
                    <?php if ( $atts['video_url'] ) : ?>
                        <video
                            class="kpy-sg-video"
                            src="<?php echo esc_url( $atts['video_url'] ); ?>"
                            autoplay
                            loop
                            muted
                            playsinline
                            preload="auto"
                        ></video>
                    <?php else : ?>
                        <div class="kpy-sg-video kpy-sg-video--placeholder"></div>
                    <?php endif; ?>
                    <!-- NO OVERLAY GRADIENT - JUST CLEAN VIDEO -->
                </div>

                <!-- ── Service Cards ── -->
                <?php if ( $pages ) : ?>
                    <?php foreach ( $pages as $index => $page ) : ?>
                        <?php
                        $icon_id  = get_post_meta( $page->ID, 'service_icon', true );
                        $icon_url = $icon_id ? wp_get_attachment_image_url( $icon_id, 'full' ) : '';
                        $link     = get_permalink( $page->ID );
                        $name     = get_the_title( $page );
                        
                        // Beautiful Font Awesome icons - RED
                        $fa_icons = [
                            'rocket' => 'fa-rocket',
                            'chart' => 'fa-chart-simple',
                            'gear' => 'fa-gear',
                            'globe' => 'fa-globe',
                            'shield' => 'fa-shield-halved',
                            'puzzle' => 'fa-puzzle-piece',
                            'code' => 'fa-code',
                            'palette' => 'fa-palette',
                            'camera' => 'fa-camera',
                            'mobile' => 'fa-mobile-screen',
                            'database' => 'fa-database',
                            'cloud' => 'fa-cloud',
                            'users' => 'fa-users',
                            'building' => 'fa-building',
                            'chart-line' => 'fa-chart-line',
                            'bullhorn' => 'fa-bullhorn',
                            'magnifying-glass' => 'fa-magnifying-glass',
                            'pen' => 'fa-pen',
                            'cpu' => 'fa-microchip',
                            'server' => 'fa-server'
                        ];
                        
                        $icon_keys = array_keys($fa_icons);
                        $selected_icon = $icon_keys[abs(crc32($page->ID . $index)) % count($icon_keys)];
                        $fa_icon_class = $fa_icons[$selected_icon];
                        ?>
                        <a href="<?php echo esc_url( $link ); ?>" class="kpy-sg-card kpy-sg-card--service">
                            <div class="kpy-sg-card__glass-bg"></div>
                            <div class="kpy-sg-card__inner">
                                <?php if ( $icon_url ) : ?>
                                    <img class="kpy-sg-icon" src="<?php echo esc_url( $icon_url ); ?>" alt="<?php echo esc_attr( $name ); ?> icon" loading="lazy" />
                                <?php else : ?>
                                    <!-- RED Font Awesome Icon -->
                                    <div class="kpy-sg-icon-container">
                                        <i class="fas <?php echo $fa_icon_class; ?> kpy-sg-fa-icon"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="kpy-sg-card__name"><?php echo esc_html( $name ); ?></span>
                            </div>
                            
                            <!-- Glass edge highlight -->
                            <div class="kpy-sg-card__edge-highlight"></div>
                        </a>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="kpy-sg-empty">No services found for category <em><?php echo esc_html( $atts['category'] ); ?></em>.</p>
                <?php endif; ?>

            </div><!-- /.kpy-sg-grid -->
        </div><!-- /.kpy-sg-wrapper -->

        <?php
        // ── Inline CSS with glassy RGB background ────────────────────
        ?>
      

   

        <?php
        return ob_get_clean();
    }

    add_shortcode( 'kpy_services_grid', 'kpy_services_grid_shortcode' );
}