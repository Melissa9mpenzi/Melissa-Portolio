<!-- Footer Section -->
<footer class="tech-footer">
    <!-- Background Image with Overlay -->
    <div class="footer-background">
        <div class="overlay"></div>
        <!-- Image that shakes (separate from overlay) -->
        <div class="shaking-image"></div>
    </div>
    
    <div class="container">
        <!-- Main Footer Content - Four Columns -->
        <div class="row g-5">
            <!-- Column 1: Logo & Company Info - ENTIRE COLUMN with red background and overlap -->
            <div class="col-lg-3">
                <div class="footer-widget logo-column-wrapper">
                    <!-- Logo -->
                    <div class="footer-logo">
                        <?php if (has_custom_logo()): ?>
                            <?php the_custom_logo(); ?>
                        <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/lwegatech-logo.png" alt="LWEGATECH" class="logo-image">
                            <h3 class="logo-text">LWEGATECH</h3>
                        <?php endif; ?>
                    </div>
                    
                    <p class="footer-description">
                        Your trusted technology partner since 2008. 
                    </p>
                    
                    <div class="footer-contact">
                        <p><i class="fas fa-map-marker-alt"></i> Kampala, Uganda</p>
                        <p><i class="fas fa-phone-alt"></i> +256 (0) 123 456 789</p>
                        <p><i class="fas fa-envelope"></i> info@lwegatech.com</p>
                    </div>
                </div>
            </div>
            
            <!-- Column 2: Quick Links -->
            <div class="col-lg-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="/"><i class="fas fa-chevron-right"></i> Home</a></li>
                        <li><a href="/about"><i class="fas fa-chevron-right"></i> About Us</a></li>
                        <li><a href="/services"><i class="fas fa-chevron-right"></i> Services</a></li>
                        <li><a href="/packages"><i class="fas fa-chevron-right"></i> Packages</a></li>
                        <li><a href="/team"><i class="fas fa-chevron-right"></i> Our Team</a></li>
                        <li><a href="/contact"><i class="fas fa-chevron-right"></i> Contact</a></li>
                    </ul>
                </div>
            </div>
            
            <!-- Column 3: Our Services -->
            <div class="col-lg-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title">Our Services</h4>
                    <ul class="footer-links">
                        <li><a href="/services/website-design"><i class="fas fa-chevron-right"></i> Website Design</a></li>
                        <li><a href="/services/e-commerce"><i class="fas fa-chevron-right"></i> E-Commerce</a></li>
                        <li><a href="/services/custom-software"><i class="fas fa-chevron-right"></i> Custom Software</a></li>
                        <li><a href="/services/web-hosting"><i class="fas fa-chevron-right"></i> Web Hosting</a></li>
                        <li><a href="/services/domain-registration"><i class="fas fa-chevron-right"></i> Domain Registration</a></li>
                        <li><a href="/services/seo-maintenance"><i class="fas fa-chevron-right"></i> SEO & Maintenance</a></li>
                    </ul>
                </div>
            </div>
            
            <!-- Column 4: Connect & CTA -->
            <div class="col-lg-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title">Connect With Us</h4>
                    
                    <!-- Social Media Icons -->
                    <div class="social-links">
                        <a href="#" class="social-link" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                    
                    <!-- CTA Button -->
                    <div class="footer-cta">
                        <a href="/consultation" class="footer-button">
                            <i class="fas fa-calendar-check"></i> Contact
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="copyright">
                        <i class="far fa-copyright"></i> <?php echo date('Y'); ?> LWEGATECH. All rights reserved. | 
                        <span class="year-badge"><i class="fas fa-calendar-alt"></i> Since 2008</span>
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="footer-meta">
                        <span class="meta-item"><i class="fas fa-shield-alt"></i> Secure</span>
                        <span class="meta-item"><i class="fas fa-clock"></i> 24/7 Support</span>
                        <span class="meta-item"><i class="fas fa-heart"></i> Made in Uganda</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>



