<?php
/**
 * Template Name: App - Web Maintenance
 *
 * @package Kipya
 */

get_header();
include get_template_directory() . '/inc/menus/menu.php';

if (function_exists('kipya_render_service_template')) {
    kipya_render_service_template(array(
        'family'        => 'web',
        'eyebrow'       => 'Care by LWEGATECH',
        'hero_title'    => 'Website Maintenance',
        'hero_subtitle' => 'Reliable, affordable, and ongoing website maintenance.',
        'gif_url'       => 'https://media.giphy.com/media/3o7aD2saalBwwftBIY/giphy.gif',
        'intro_title'   => 'Never Worry About Upkeep Again',
        'intro_text'    => "Do you have a website but struggle to keep it updated, secure, or performing well? Many business owners find it hard to balance content updates, plugin issues, and design changes while managing their daily operations. We handle updates, security, performance, and backups so you can focus on growing your business while we keep your website safe.",
        'highlights'    => array(
            array('title' => '24/7 Security Monitoring', 'text' => 'Proactive protection against malware, exploits, and brute force attacks.', 'icon' => 'fa-solid fa-shield-halved'),
            array('title' => 'Routine Backups', 'text' => 'Automated off-site backups ensure your data is never permanently lost.', 'icon' => 'fa-solid fa-cloud-arrow-up'),
            array('title' => 'Performance Tweaks', 'text' => 'Continuous optimization to keep load speeds incredibly fast for users.', 'icon' => 'fa-solid fa-bolt'),
        ),
        'packages'      => array(
            array(
                'title'    => 'WEB Care',
                'price'    => 'UGX 100,000 / mo',
                'desc'     => 'Active organizations needing frequent updates and emergency support.',
                'features' => array(
                    'Up to 5 content updates per month',
                    'Monthly CMS & plugin update',
                    'Basic security check & malware scan',
                    'Backup once every month',
                    'Minor text or image corrections',
                    '48 - 72 hour turnaround time for minor tasks',
                    'Website performance and update annual report'
                )
            ),
            array(
                'title'    => 'WEB Plus',
                'price'    => 'UGX 350,000 / mo',
                'desc'     => 'Active organizations needing frequent updates and emergency support.',
                'features' => array(
                    'Weekly content updates',
                    'Emergency uploads (within same day)',
                    'CMS & plugin updates',
                    'Security scans and protection',
                    'Broken link fixes & error troubleshooting',
                    'Image optimization',
                    'Video and gallery updates',
                    'Website performance and update monthly report'
                )
            ),
            array(
                'title'    => 'WEB Quarter',
                'price'    => 'UGX 450,000 / qtr',
                'desc'     => 'Organizations with occasional updates but wanting professional oversight.',
                'features' => array(
                    'Up to 35 content updates per quarter',
                    'CMS & plugin updates',
                    'Security scans and protection',
                    'Troubleshooting & restoration of site functionality',
                    'Regular site backups',
                    'SEO best-practice implementation',
                    'Social media updates on request',
                    'Backups & quarterly report'
                )
            )
        ),
        'faqs'          => array(
            array('q' => 'What happens if my site breaks after an update?', 'a' => 'Our team always performs exhaustive sandboxed visual checks post-update. If a rare failure happens, we immediately roll back to the automated daily backup.'),
            array('q' => 'Does maintenance cover new content additions?', 'a' => 'Depending on the tier (e.g., WEB Plus), minor content alterations and emergency layout uploads are fully bundled into your monthly care hours.'),
            array('q' => 'How do I know my site is actually being monitored?', 'a' => 'You will receive deeply detailed, fully transparent monthly reports covering exact uptime metrics, stopped attacks, and updated plugins.'),
            array('q' => 'Am I locked into a long-term contract?', 'a' => 'No. We fundamentally believe in earning your business constantly. Our WEB Care plan operates on a flexible month-to-month commitment basis.'),
            array('q' => 'What happens if I exceed my content update limit?', 'a' => 'We will alert you gracefully and provide highly affordable hourly options for the remainder of the billing period.'),
            array('q' => 'Can you maintain a site you didn\'t originally build?', 'a' => 'Yes. We will first perform a comprehensive technical audit of the codebase, then seamlessly assume maintenance responsibilities.'),
            array('q' => 'How quickly are emergency uploads processed on WEB Plus?', 'a' => 'WEB Plus guarantees same-day processing for critical emergency layout uploads or urgent news cycle integrations.'),
            array('q' => 'Is malware removal included in the plans?', 'a' => 'Our Security Scans proactively prevent malware. If your legacy site is already infected prior to joining, we will quote a flat-fee clinical removal.'),
            array('q' => 'Do you optimize images for us?', 'a' => 'Yes, WEB Plus and WEB Quarter distinctly feature ongoing image optimization protocols to guarantee your server latency strictly remains low.'),
            array('q' => 'Are backups stored safely off-site?', 'a' => 'Yes. We never keep backups locally on your host; they are deployed to secure, redundant offshore AWS/Google Cloud containers.'),
        ),
        'deliverables'  => array(
            'Daily or Monthly Off-site Backups',
            'Full Malware & Hacker Protection',
            'Routine Theme & Plugin Updates',
            'Broken Link Fixes & Error Troubleshooting',
            'Flexible Packages (Monthly/Quarterly)',
        ),
        'cta_title'     => 'Let’s Keep Your Website Running — Effortlessly.',
        'cta_text'      => 'Stop worrying about updates, downtime, and technical errors. Join dozens of businesses already trusting Lwegatech.',
        'cta_primary_label' => 'Choose a Plan',
        'cta_primary_url'   => home_url('/contact-us/'),
        'cta_secondary_label' => 'Questions?',
        'cta_secondary_url' => home_url('/contact-us/'),
    ));
}

get_footer();
