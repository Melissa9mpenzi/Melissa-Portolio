<?php
/**
 * Renders the standardized layout for web and app service templates,
 * utilizing the strict Red/Black Dark Mode design language from the screenshots.
 */

function kipya_render_service_template($args) {
    // Merge defaults
    $args = wp_parse_args($args, array(
        'family'            => 'web',
        'eyebrow'           => '',
        'hero_title'        => '',
        'hero_subtitle'     => '',
        'gif_url'           => '',
        'intro_title'       => '',
        'intro_text'        => '',
        'highlights'        => array(),
        'packages'          => array(),
        'faqs'              => array(),
        'deliverables'      => array(),
        'cta_title'         => '',
        'cta_text'          => '',
        'cta_primary_label' => '',
        'cta_primary_url'   => '',
        'cta_secondary_label' => '',
        'cta_secondary_url' => '',
    ));

    ?>
    <main role="main" style="background: #0d0d0d;">
        <!-- Hero Section (Retained Hosting style with Zoom in/out Image fix) -->
        <section class="hero-section hosting-hero <?php echo esc_attr($args['family']); ?>-hero" style="overflow: hidden; position: relative;">
            <div class="hero-black-background"></div>
            
            <div class="svg-background">
                <div class="svg-container">
                    <svg class="network-svg network-1" viewBox="0 0 300 300">
                        <path d="M50 150 L120 80 L200 120 L250 180 L180 250 L80 220 L50 150" stroke="currentColor" fill="none" stroke-dasharray="4 6"/>
                        <path d="M120 80 L200 120 M200 120 L250 180 M180 250 L80 220 M80 220 L50 150" stroke="currentColor" fill="none" stroke-width="1"/>
                        <circle cx="50" cy="150" r="6" stroke="currentColor" fill="none"/>
                        <circle cx="120" cy="80" r="6" stroke="currentColor" fill="none"/>
                        <circle cx="200" cy="120" r="6" stroke="currentColor" fill="none"/>
                        <circle cx="250" cy="180" r="6" stroke="currentColor" fill="none"/>
                        <circle cx="180" cy="250" r="6" stroke="currentColor" fill="none"/>
                        <circle cx="80" cy="220" r="6" stroke="currentColor" fill="none"/>
                    </svg>
                    <!-- other networks omitted for brevity, keeping styling clean -->
                </div>
            </div>

            <div class="hero-overlay" style="position: relative; z-index: 2;">
                <div class="container">
                    <div class="hero-content-wrapper">
                        <?php 
                        $image_url = $args['gif_url'];
                        if (has_post_thumbnail()) {
                            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                            if($thumb) $image_url = $thumb[0];
                        }
                        if ($image_url) : ?>
                            <div class="hero-thumbnail" style="overflow:hidden; border-radius: 12px;">
                                <div class="hero-thumbnail-inner image-zoom-wrap">
                                    <img src="<?php echo esc_url($image_url); ?>" 
                                         alt="<?php echo esc_attr($args['hero_title']); ?>" 
                                         class="hero-featured-image zoom-in-out-effect" style="width:100%; height:100%; object-fit:cover;">
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="hero-text-content">
                            <?php if($args['eyebrow']): ?>
                            <div class="hero-badge" style="display:inline-block; padding:8px 16px; background:rgba(255,255,255,0.1); border-radius:30px; font-size:0.9rem; font-weight:600; color:#fff; border:1px solid rgba(255,255,255,0.2); margin-bottom:1.5rem;">
                                <i class="bi bi-star-fill" style="color:#c0000c; margin-right:8px;"></i> <?php echo esc_html($args['eyebrow']); ?>
                            </div>
                            <?php endif; ?>
                            <h1 class="kpy-sg-title" style="margin-bottom:1rem; font-size:3.5rem; line-height:1.2; color:#fff;"><?php echo esc_html($args['hero_title']); ?></h1>
                            <p style="color:rgba(255,255,255,0.7); font-size:1.1rem; line-height:1.6; max-width:600px;"><?php echo esc_html($args['hero_subtitle']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- First Section (Never Worry About Upkeep Again) -->
        <section class="intro-highlights-section dark-waves-bg" style="padding: 7rem 0; background-color: #0d0d0d; color: #fff; position: relative;">
            <div class="container" style="position:relative; z-index:2;">
                <div class="text-center" style="text-align:center; max-width:800px; margin: 0 auto 4rem;">
                    <h2 style="font-size: 2.8rem; font-weight: 900; text-transform: uppercase; color: #fff; letter-spacing: -0.02em; margin-bottom:1.5rem; line-height:1.2;">
                        <?php echo esc_html($args['intro_title']); ?>
                    </h2>
                    <p style="font-size: 1.1rem; line-height: 1.7; color: #aaa;">
                        <?php echo nl2br(esc_html($args['intro_text'])); ?>
                    </p>
                </div>

                <div class="columns is-multiline is-centered" style="display:flex; flex-wrap:wrap; justify-content:center; gap:2rem;">
                    <?php foreach ($args['highlights'] as $hl) : ?>
                        <div class="column is-4" style="width:calc(33.333% - 1.5rem); min-width:280px; padding:0;">
                            <div class="highlight-card-wrapper" style="position:relative; height:100%; z-index:1;">
                                <div class="highlight-card-bg"></div>
                                <div class="dark-card" style="background:#131313; border-radius:16px; padding:3rem 2rem; height:100%; position:relative; z-index:2;">
                                    <!-- Red Icon Container -->
                                    <div class="icon-container" style="background:#c0000c; width:64px; height:64px; border-radius:16px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:1.8rem; margin-bottom:1.5rem;">
                                        <i class="<?php echo esc_attr($hl['icon']); ?>"></i>
                                    </div>
                                    <h3 style="font-size:1.4rem; font-weight:800; color:#fff; margin-bottom:1rem; line-height:1.3;"><?php echo esc_html($hl['title']); ?></h3>
                                    <p style="color:#aaa; font-size:1rem; line-height:1.6; margin:0;"><?php echo esc_html($hl['text']); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- What You Get Section -->
        <?php if (!empty($args['deliverables'])) : ?>
        <section class="deliverables-section" style="padding: 7rem 0; background: #0a0a0a; border-top: 1px solid #222;">
            <div class="container">
                <div class="columns is-vcentered" style="display:flex; flex-wrap:wrap; gap:4rem; align-items:center;">
                    <!-- Left: Checklist -->
                    <div class="column is-5" style="flex:1; min-width:300px;">
                        <h2 style="font-size:3.2rem; font-weight:900; color:#fff; margin-bottom:2.5rem; line-height:1.1;">What You Get</h2>
                        <ul style="list-style:none; padding:0; margin:0;">
                            <?php foreach ($args['deliverables'] as $deliv) : ?>
                                <li style="display:flex; align-items:center; gap:1.2rem; margin-bottom:1.5rem; padding-bottom:1.5rem; border-bottom:1px solid #222;">
                                    <i class="bi bi-check" style="color:#c0000c; font-size:1.8rem; line-height:1;"></i>
                                    <span style="color:#fff; font-size:1.05rem; font-weight:600;"><?php echo esc_html($deliv); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <!-- Right: Large Image with red offset -->
                    <div class="column is-7" style="flex:1; min-width:320px; display:flex; justify-content:flex-end;">
                        <div style="position:relative; width:100%; max-width:500px; margin-left:auto;">
                            <!-- Red Offset Shadow block -->
                            <div style="position:absolute; top:20px; left:-20px; right:-20px; bottom:-20px; background:#c0000c; z-index:0;"></div>
                            <!-- Main White Image container -->
                            <div style="background:#fff; padding:10px; position:relative; z-index:1; border: 2px solid #000;">
                                <?php 
                                $deliverables_img = 'https://i.pinimg.com/736x/ec/6a/b2/ec6ab2ca543e90f89c13a89aa5bbba25.jpg'; 
                                ?>
                                <img src="<?php echo esc_url($deliverables_img); ?>" alt="What You Get Illustration" style="width:100%; height:auto; display:block;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Pricing Packages -->
        <?php if (!empty($args['packages'])) : ?>
        <section class="pricing-section" style="padding:6rem 0; background:#111; border-top: 1px solid #222;">
            <div class="container">
                <div class="text-center" style="margin-bottom:3rem; text-align:center;">
                    <h2 style="font-size:2.8rem; font-weight:900; color:#fff; text-transform:uppercase;">Our Packages</h2>
                </div>
                <div class="pricing-grid" style="display:flex; flex-wrap:wrap; gap:1.5rem; justify-content:center;">
                    <?php foreach ($args['packages'] as $index => $pkg) : ?>
                    <div class="pricing-card" style="background:#1a1a1a; border:1px solid #333; border-radius:12px; padding:2.5rem; flex:1; min-width:280px; max-width:350px;">
                        <div style="color:#c0000c; font-weight:800; font-size:0.9rem; letter-spacing:1px; margin-bottom:0.5rem;"><?php echo strtoupper(esc_html($pkg['title'])); ?></div>
                        <div style="color:#888; font-size:0.9rem; margin-bottom:1.5rem; min-height:40px;"><?php echo esc_html($pkg['desc']); ?></div>
                        <?php if (!empty($pkg['price'])) : ?>
                            <div style="color:#fff; font-size:1.8rem; font-weight:800; margin-bottom:2rem;"><?php echo esc_html($pkg['price']); ?></div>
                        <?php endif; ?>
                        <ul style="list-style:none; padding:0; margin:0 0 2rem;">
                            <?php foreach ((array)$pkg['features'] as $feature) : ?>
                                <li style="color:#ddd; font-size:0.9rem; margin-bottom:1rem; display:flex; gap:10px;">
                                    <i class="bi bi-check-circle-fill" style="color:#c0000c; flex-shrink:0; margin-top:3px;"></i> 
                                    <span><?php echo esc_html($feature); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- FAQs Section (3 Columns) -->
        <?php if (!empty($args['faqs'])) : ?>
        <section class="faqs-section" style="padding:7rem 0; background:#0a0a0a; border-top:1px solid #222;">
            <div class="container text-center">
                <h2 style="font-size:2.8rem; font-weight:900; color:#fff; text-transform:uppercase; margin-bottom:4rem;">Frequently Asked Questions</h2>
                
                <?php
                $total_faqs = count($args['faqs']);
                $half = ceil($total_faqs / 2);
                $left_faqs = array_slice($args['faqs'], 0, $half);
                $right_faqs = array_slice($args['faqs'], $half);
                ?>
                
                <div class="columns is-vcentered" style="display:flex; flex-wrap:wrap; gap:2rem; align-items:stretch;">
                    <!-- 1st Column: Left FAQs -->
                    <div class="column is-4" style="flex:1; min-width:300px; text-align:left;">
                        <?php foreach ($left_faqs as $faq) : ?>
                            <div class="dark-faq-item" style="border-bottom:1px solid #333; padding:1.2rem 0; cursor:pointer;" onclick="this.classList.toggle('active')">
                                <div style="display:flex; justify-content:space-between; align-items:center; font-weight:600; font-size:1.05rem; color:#fff;">
                                    <span><?php echo esc_html($faq['q']); ?></span>
                                    <i class="bi bi-chevron-down kpy-faq-toggle" style="color:#c0000c; transition:transform 0.3s; flex-shrink:0; margin-left:10px;"></i>
                                </div>
                                <div class="kpy-faq-answer">
                                    <p style="padding-top:1rem; color:#aaa; font-size:0.95rem; line-height:1.6;"><?php echo nl2br(esc_html($faq['a'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- 2nd Column: Pinterest Cartoon Image -->
                    <div class="column is-4" style="flex:1; min-width:300px; display:flex; align-items:center; justify-content:center;">
                        <div style="width:100%; height:100%; border-radius:12px; overflow:hidden;">
                            <?php 
                            $cartoon_url = 'https://i.pinimg.com/736x/9f/13/48/9f13480d95fa12cfc03cb4f50039e792.jpg';
                            ?>
                            <img src="<?php echo esc_url($cartoon_url); ?>" alt="Cartoon Illustration" style="width:100%; object-fit:contain; border-radius:12px; opacity:0.9;">
                        </div>
                    </div>

                    <!-- 3rd Column: Right FAQs -->
                    <div class="column is-4" style="flex:1; min-width:300px; text-align:left;">
                        <?php foreach ($right_faqs as $faq) : ?>
                            <div class="dark-faq-item" style="border-bottom:1px solid #333; padding:1.2rem 0; cursor:pointer;" onclick="this.classList.toggle('active')">
                                <div style="display:flex; justify-content:space-between; align-items:center; font-weight:600; font-size:1.05rem; color:#fff;">
                                    <span><?php echo esc_html($faq['q']); ?></span>
                                    <i class="bi bi-chevron-down kpy-faq-toggle" style="color:#c0000c; transition:transform 0.3s; flex-shrink:0; margin-left:10px;"></i>
                                </div>
                                <div class="kpy-faq-answer">
                                    <p style="padding-top:1rem; color:#aaa; font-size:0.95rem; line-height:1.6;"><?php echo nl2br(esc_html($faq['a'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- CTA Section - Red Card on Black Background -->
        <section class="cta-section dark-waves-bg" style="padding:4rem 0 8rem; background:#0d0d0d; position:relative;">
            <div class="container" style="position:relative; z-index:2;">
                <!-- Red Box -->
                <div style="background:#c0000c; padding:4rem; border-radius:8px;">
                    <div class="columns" style="display:flex; flex-wrap:wrap; gap:4rem; align-items:center; margin:0;">
                        <!-- Left: Texts and Buttons -->
                        <div class="column is-6" style="flex:1; min-width:320px; padding:0;">
                            <h2 style="color:#fff; font-size:3.5rem; font-weight:800; line-height:1.1; margin-bottom:1.5rem; letter-spacing:-0.03em;">
                                <?php echo nl2br(esc_html($args['cta_title'])); ?>
                            </h2>
                            <p style="color:#111; font-size:1.15rem; line-height:1.6; margin-bottom:3rem; font-weight:600;">
                                <?php echo esc_html($args['cta_text']); ?>
                            </p>
                            
                            <div style="display:flex; gap:1rem; flex-wrap:wrap;">
                                <?php if (!empty($args['cta_primary_label'])) : ?>
                                    <a href="<?php echo esc_url($args['cta_primary_url']); ?>" style="background:#000; color:#fff; font-weight:800; font-size:0.95rem; text-transform:uppercase; border:none; padding:1.2rem 2rem; display:inline-block; text-decoration:none; cursor:pointer; min-width:180px; text-align:center;" class="cta-btn-black">
                                        <?php echo esc_html($args['cta_primary_label']); ?>
                                    </a>
                                <?php endif; ?>
                                <?php if (!empty($args['cta_secondary_label'])) : ?>
                                    <a href="<?php echo esc_url($args['cta_secondary_url']); ?>" style="background:#c0000c; border:2px solid #000; color:#000; font-weight:800; font-size:0.95rem; text-transform:uppercase; padding:1.1rem 2rem; display:inline-block; text-decoration:none; cursor:pointer; min-width:180px; text-align:center;" class="cta-btn-outline">
                                        <?php echo esc_html($args['cta_secondary_label']); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- Right: Image with Black Drop Shadow -->
                        <div class="column is-6" style="flex:1; min-width:320px; display:flex; justify-content:center; padding:0;">
                            <div style="position:relative; width:100%; max-width:400px;">
                                <!-- Solid Black offset shadow -->
                                <div style="position:absolute; top:20px; left:20px; right:-20px; bottom:-20px; background:#000; z-index:0;"></div>
                                <!-- White box containing Image -->
                                <div style="background:#fff; padding:8px; position:relative; z-index:1; border:2px solid #000;">
                                    <?php 
                                    $cta_cartoon = 'https://i.pinimg.com/1200x/13/db/f6/13dbf6c2e6cf65c2cd3dc6c40e1cdfab.jpg'; 
                                    ?>
                                    <img src="<?php echo esc_url($cta_cartoon); ?>" alt="CTA Character" style="width:100%; height:auto; display:block;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <style>
            /* Zoom In & Out animation for the Hero Image */
            @keyframes zoomInOut {
                0% { transform: scale(1); }
                50% { transform: scale(1.15); }
                100% { transform: scale(1); }
            }
            .zoom-in-out-effect {
                animation: zoomInOut 15s infinite ease-in-out;
                will-change: transform;
            }

            /* FAQ Accordions Open State */
            .kpy-faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out; }
            .dark-faq-item.active .kpy-faq-answer { max-height: 1000px; }
            .dark-faq-item.active .kpy-faq-toggle { transform: rotate(180deg); }
            
            /* CTA Buttons */
            .cta-btn-black:hover {
                background: #222 !important;
                transform: translateY(-2px);
            }
            .cta-btn-outline:hover {
                background: #000 !important;
                color: #fff !important;
                transform: translateY(-2px);
            }

            /* Intro Waves Background - subtle repeating lines */
            .dark-waves-bg::before {
                content: "";
                position: absolute;
                top:0; left:0; right:0; bottom:0;
                background-image: repeating-linear-gradient(45deg, rgba(192,0,12,0.02) 0px, rgba(192,0,12,0.02) 2px, transparent 2px, transparent 15px);
                z-index: 0;
                pointer-events: none;
            }

            /* Highlight Card Hover Effect (Red Offset Sub-layer) */
            .highlight-card-bg {
                position: absolute;
                top: 0; left: 0; right: 0; bottom: 0;
                background: #c0000c;
                border-radius: 16px;
                z-index: 1;
                transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.3s;
                opacity: 0;
            }
            .highlight-card-wrapper:hover .highlight-card-bg {
                opacity: 1;
                transform: translate(12px, 12px);
            }
        </style>
    </main>
    <?php
}
?>
