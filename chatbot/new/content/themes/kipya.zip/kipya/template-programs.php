<?php /* Template Name: Safaris Page Template */ get_header(); 
    include get_template_directory() . '/inc/menus/menu.php'; 
?>
	<main role="main">
		<?php $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );?>
		<section class="header-wrap-services" style="background: linear-gradient(to top, rgba(94, 196, 1, 0.05), rgba(94, 196, 1, 0.1)), url('<?php echo $backgroundImg[0]; ?>') no-repeat;background-size: cover;background-position: top center; ">
		    <div class="overlay">
		    <div class="page-title">
                    <div class="row justify-content-between">
						<div class="col-lg-12" data-aos="fade-up"> 
							<h1 class="entry-title"><?php the_title(); ?></h1>
							<?php custom_breadcrumb(); ?>
						</div>
                    </div>
		    </div>
		    </div>
        </section><!-- Header Section !-->
		<section>
		    <div class="content-area" data-aos="fade-up">
		        <?php if (have_posts()): while (have_posts()) : the_post(); ?>

			<!-- article -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<?php the_content(); ?>
				
				<?php edit_post_link(); ?>

			</article>
			<!-- /article -->

		<?php endwhile; ?>

		<?php else: ?>

			<!-- article -->
			<article>

				<h2><?php _e( 'Sorry, nothing to display.', 'kipya' ); ?></h2>

			</article>
			<!-- /article -->

		<?php endif; ?>
		    </div>
		</section>
		<!-- /section -->
 </main>

<?php get_footer(); ?>
