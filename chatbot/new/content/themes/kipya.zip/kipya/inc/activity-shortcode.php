<?php
/*
Plugin Name: IWCA Core Values Shortcode
Description: Display core values cards with background image
Version: 1.0
*/

// Shortcode to display core values cards with background image
function iwca_core_values_shortcode($atts) {
    $atts = shortcode_atts(array(
        'bg_image' => '',
        'title' => 'OUR CORE VALUES'
    ), $atts);
    
    $values = array(
        'Respect' => array(
            'icon' => '<i class="fas fa-hands-helping"></i>',
            'desc' => 'The IWCA Uganda Chapter acknowledges the fact that its membership comes from different backgrounds.'
        ),
        'Integrity' => array(
            'icon' => '<i class="fas fa-shield-alt"></i>',
            'desc' => 'Maintaining integrity in the coffee industry will be key to achieving success throughout the entire value chain.'
        ),
        'Collaboration' => array(
            'icon' => '<i class="fas fa-users"></i>',
            'desc' => 'The IWCA Uganda Chapter will promote collaboration with like-minded stakeholders at all stages of the value chain.'
        ),
        'Equity' => array(
            'icon' => '<i class="fas fa-balance-scale"></i>',
            'desc' => 'The IWCA Uganda Chapter will pursue fairness at all stages of the coffee value chain.'
        ),
        'Sustainability' => array(
            'icon' => '<i class="fas fa-leaf"></i>',
            'desc' => 'Sustainability of benefits derived from the coffee industry will be of special interest to the IWCA Uganda Chapter.'
        )
    );
    
    $bg_style = $atts['bg_image'] ? 'style="background: linear-gradient(rgba(92,50,36,0.9), rgba(92,50,36,0.85)), url(' . esc_url($atts['bg_image']) . ')"' : '';
    
    ob_start(); ?>
    
    <section class="iwca-core-values-section" <?php echo $bg_style; ?>>
        <div class="iwca-values-container">
            <h2><?php echo esc_html($atts['title']); ?></h2>
            
            <div class="iwca-values-grid">
                <?php foreach ($values as $title => $data): ?>
                    <div class="iwca-value-card">
                        <div class="iwca-card-icon"><?php echo $data['icon']; ?></div>
                        <h3><?php echo esc_html($title); ?></h3>
                        <p><?php echo esc_html($data['desc']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <?php return ob_get_clean();
}
add_shortcode('iwca_core_values', 'iwca_core_values_shortcode');


?>