<?php
/**
 * Template Name: Domain Transfers Page
 * Description: Template for displaying domain transfer information
 */

get_header();
include get_template_directory() . '/inc/menus/menu.php';
?>

<main role="main">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    
    <section class="hero-section hosting-hero">
        <!-- Solid black background -->
        <div class="hero-black-background"></div>

        <!-- SVG Background Layer with animated networks -->
        <div class="svg-background">
            <div class="svg-container">
                <svg class="network-svg network-1" viewBox="0 0 300 300">
                    <path d="M50 150 L120 80 L200 120 L250 180 L180 250 L80 220 L50 150" stroke="currentColor" fill="none" stroke-dasharray="4 6"/>
                    <path d="M120 80 L200 120 M200 120 L250 180 M180 250 L80 220 M80 220 L50 150" stroke="currentColor" fill="none" stroke-width="1"/>
                    <circle cx="50" cy="150" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="80" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="200" cy="120" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="250" cy="180" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="180" cy="250" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="80" cy="220" r="6" stroke="currentColor" fill="none"/>
                    <path d="M120 80 L80 220 M200 120 L180 250 M250 180 L50 150" stroke="currentColor" fill="none" stroke-dasharray="3 8" opacity="0.6"/>
                </svg>
                <svg class="network-svg network-2" viewBox="0 0 300 300">
                    <path d="M150 30 L240 90 L240 210 L150 270 L60 210 L60 90 L150 30" stroke="currentColor" fill="none" stroke-dasharray="5 5"/>
                    <path d="M150 30 L150 270 M60 90 L240 210 M60 210 L240 90" stroke="currentColor" fill="none" opacity="0.5"/>
                    <circle cx="150" cy="30" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="240" cy="90" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="240" cy="210" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="270" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="60" cy="210" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="60" cy="90" r="5" stroke="currentColor" fill="none"/>
                </svg>
                <svg class="network-svg network-3" viewBox="0 0 300 300">
                    <path d="M50 50 L250 50 M50 120 L250 120 M50 190 L250 190 M50 260 L250 260" stroke="currentColor" fill="none" opacity="0.4"/>
                    <path d="M50 50 L50 260 M120 50 L120 260 M190 50 L190 260 M260 50 L260 260" stroke="currentColor" fill="none" opacity="0.4"/>
                    <circle cx="50" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <path d="M50 50 L260 260 M260 50 L50 260" stroke="currentColor" fill="none" stroke-dasharray="6 6" opacity="0.3"/>
                </svg>
                <svg class="network-svg network-4" viewBox="0 0 300 300">
                    <circle cx="150" cy="150" r="50" stroke="currentColor" fill="none" stroke-dasharray="4 8"/>
                    <circle cx="150" cy="150" r="100" stroke="currentColor" fill="none" stroke-dasharray="4 6"/>
                    <path d="M150 30 L150 270 M30 150 L270 150 M70 70 L230 230 M230 70 L70 230" stroke="currentColor" fill="none" opacity="0.5"/>
                    <circle cx="150" cy="150" r="8" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="250" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="150" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="250" cy="150" r="4" stroke="currentColor" fill="none"/>
                </svg>
                <svg class="network-svg network-5" viewBox="0 0 300 300">
                    <circle cx="150" cy="150" r="40" stroke="currentColor" fill="none" opacity="0.4"/>
                    <circle cx="150" cy="150" r="80" stroke="currentColor" fill="none" opacity="0.4"/>
                    <circle cx="150" cy="150" r="120" stroke="currentColor" fill="none" opacity="0.4"/>
                    <path d="M150 30 L150 270" stroke="currentColor" fill="none" opacity="0.3"/>
                    <path d="M30 150 L270 150" stroke="currentColor" fill="none" opacity="0.3"/>
                    <path d="M70 70 L230 230" stroke="currentColor" fill="none" opacity="0.3"/>
                    <path d="M230 70 L70 230" stroke="currentColor" fill="none" opacity="0.3"/>
                    <circle cx="150" cy="150" r="8" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="70" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="230" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="70" cy="150" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="230" cy="150" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="100" cy="100" r="3" stroke="currentColor" fill="none"/>
                    <circle cx="200" cy="200" r="3" stroke="currentColor" fill="none"/>
                    <circle cx="100" cy="200" r="3" stroke="currentColor" fill="none"/>
                    <circle cx="200" cy="100" r="3" stroke="currentColor" fill="none"/>
                </svg>
            </div>
        </div>

        <div class="connection-lines"></div>
        <div class="grid-lines"></div>

        <!-- Hero Content -->
        <div class="hero-overlay">
            <div class="container">
                <div class="hero-content-wrapper">
                    <?php if (has_post_thumbnail()) : 
                        $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
                        $thumbnail_alt = get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true);
                    ?>
                        <div class="hero-thumbnail">
                            <div class="hero-thumbnail-inner">
                                <img src="<?php echo esc_url($thumbnail_url[0]); ?>" 
                                     alt="<?php echo esc_attr($thumbnail_alt ?: get_the_title()); ?>" 
                                     class="hero-featured-image">
                                <div class="hero-thumbnail-overlay">
                                    <i class="bi bi-arrow-right-circle-fill"></i>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="hero-text-content">
                        <div class="hero-badge">
                            <i class="bi bi-arrow-left-right"></i> Domain Transfer Services
                        </div>
                        <h1 class="kpy-sg-title"><?php the_title(); ?></h1>
                    </div>
                </div>
                
                <!-- Feature Circles - Horizontal line at bottom -->
                <div class="feature-circles-wrapper">
                    <div class="feature-circles">
                        <div class="feature-circle"><i class="bi bi-lightning-charge-fill"></i><span>Fast Transfer</span></div>
                        <div class="feature-circle"><i class="bi bi-shield-check-fill"></i><span>Secure Process</span></div>
                        <div class="feature-circle"><i class="bi bi-calendar-check-fill"></i><span>No Downtime</span></div>
                        <div class="feature-circle"><i class="bi bi-graph-up"></i><span>Free Transfer</span></div>
                        <div class="feature-circle"><i class="bi bi-headset"></i><span>24/7 Support</span></div>
                        <div class="feature-circle"><i class="bi bi-globe2"></i><span>All TLDs Supported</span></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQs Section -->
    <section class="faqs-section">
        <div class="container">
           <div class="kpy-sg-header">
            <div class="kpy-sg-title-container">
                <div class="kpy-sg-title-bg" aria-hidden="true">
                    Transfer Domain FAQs
                </div>

                <!-- MAIN TITLE -->
                <h2 class="kpy-sg-title">
                    <span class="kpy-sg-title-red">Frequently </span>
                    <span class="kpy-sg-title-white">Asked Questions</span>
                </h2>
            </div>
            
            <div class="faqs-grid">
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What is domain transfer and why should I transfer?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Domain transfer is the process of moving your domain name registration from one registrar to another. Transferring to Lwegatech gives you access to better pricing, enhanced security features, free SSL certificates, 24/7 expert support, and seamless integration with our hosting services.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>How long does a domain transfer take?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Domain transfers typically take 5-7 days to complete. The process involves verification steps and waiting periods required by ICANN regulations. However, you can speed up the process by approving the transfer request through your current registrar's email confirmation.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Will my website experience downtime during transfer?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>No, your website will not experience any downtime during the domain transfer process. Your domain will continue to function normally with your current hosting provider until the transfer is complete. We ensure a seamless transition with zero disruption to your website visitors.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What do I need to transfer my domain?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>To transfer your domain, you'll need: 1) An authorization code (EPP code) from your current registrar, 2) Your domain must be unlocked for transfer, 3) Your domain must be at least 60 days old, and 4) Your domain should not be within 15 days of expiration. Our support team will guide you through each step.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Is there a fee for domain transfer?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, domain transfers typically include a one-year registration renewal fee. Many TLDs include free transfer with hosting purchase. Check our current promotions - we often offer free domain transfers when you sign up for any hosting plan.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What domain extensions can I transfer?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>We support transfer for most major domain extensions including .com, .net, .org, .info, .biz, .co.ug, .ug, .ac.ug, and many more. If you have a specific TLD, please contact our support team to verify transfer availability.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Can I transfer an expired domain?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Domains that have expired may still be transferable depending on the grace period offered by your current registrar. Typically, domains can be transferred within 30-45 days after expiration. After that, the domain may be released and you'll need to register it again.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What happens to my email and DNS settings?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Your DNS settings and email configurations remain unchanged during the transfer process. You have the option to keep your existing DNS settings or update them to use Lwegatech's nameservers. We recommend keeping your current settings until the transfer is complete.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Can I transfer multiple domains at once?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, you can transfer multiple domains in a single transaction. Our bulk transfer tool allows you to process multiple domain transfers simultaneously. Each domain requires its own authorization code, and you can track the status of all transfers from your dashboard.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What happens to the remaining time on my domain?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>When you transfer a domain, you typically get an additional year added to your registration period. The remaining time from your current registrar is not lost - it's combined with the new registration period, giving you extended domain ownership at no extra cost.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>

<script>
// FAQ Accordion Functionality
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            item.classList.toggle('active');
        });
    });
});
</script>