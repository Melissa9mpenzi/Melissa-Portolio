<?php
/**
 * Template Name: Web Hosting Page
 * Description: Template for displaying web hosting plans and pricing
 */

get_header();
include get_template_directory() . '/inc/menus/menu.php';
?>

<main role="main">
    <section class="hero-section hosting-hero">
        <!-- Solid black background -->
        <div class="hero-black-background"></div>

        <!-- SVG Background Layer with animated networks -->
        <div class="svg-background">
            <div class="svg-container">
                <svg class="network-svg network-1" viewBox="0 0 300 300">
                    <path d="M50 150 L120 80 L200 120 L250 180 L180 250 L80 220 L50 150" stroke="currentColor" fill="none" stroke-dasharray="4 6"/>
                    <path d="M120 80 L200 120 M200 120 L250 180 M180 250 L80 220 M80 220 L50 150" stroke="currentColor" fill="none" stroke-width="1"/>
                    <circle cx="50" cy="150" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="80" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="200" cy="120" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="250" cy="180" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="180" cy="250" r="6" stroke="currentColor" fill="none"/>
                    <circle cx="80" cy="220" r="6" stroke="currentColor" fill="none"/>
                    <path d="M120 80 L80 220 M200 120 L180 250 M250 180 L50 150" stroke="currentColor" fill="none" stroke-dasharray="3 8" opacity="0.6"/>
                </svg>
                <svg class="network-svg network-2" viewBox="0 0 300 300">
                    <path d="M150 30 L240 90 L240 210 L150 270 L60 210 L60 90 L150 30" stroke="currentColor" fill="none" stroke-dasharray="5 5"/>
                    <path d="M150 30 L150 270 M60 90 L240 210 M60 210 L240 90" stroke="currentColor" fill="none" opacity="0.5"/>
                    <circle cx="150" cy="30" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="240" cy="90" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="240" cy="210" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="270" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="60" cy="210" r="5" stroke="currentColor" fill="none"/>
                    <circle cx="60" cy="90" r="5" stroke="currentColor" fill="none"/>
                </svg>
                <svg class="network-svg network-3" viewBox="0 0 300 300">
                    <path d="M50 50 L250 50 M50 120 L250 120 M50 190 L250 190 M50 260 L250 260" stroke="currentColor" fill="none" opacity="0.4"/>
                    <path d="M50 50 L50 260 M120 50 L120 260 M190 50 L190 260 M260 50 L260 260" stroke="currentColor" fill="none" opacity="0.4"/>
                    <circle cx="50" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="120" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="190" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="120" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="190" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="260" cy="260" r="4" stroke="currentColor" fill="none"/>
                    <path d="M50 50 L260 260 M260 50 L50 260" stroke="currentColor" fill="none" stroke-dasharray="6 6" opacity="0.3"/>
                </svg>
                <svg class="network-svg network-4" viewBox="0 0 300 300">
                    <circle cx="150" cy="150" r="50" stroke="currentColor" fill="none" stroke-dasharray="4 8"/>
                    <circle cx="150" cy="150" r="100" stroke="currentColor" fill="none" stroke-dasharray="4 6"/>
                    <path d="M150 30 L150 270 M30 150 L270 150 M70 70 L230 230 M230 70 L70 230" stroke="currentColor" fill="none" opacity="0.5"/>
                    <circle cx="150" cy="150" r="8" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="50" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="250" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="50" cy="150" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="250" cy="150" r="4" stroke="currentColor" fill="none"/>
                </svg>
                <svg class="network-svg network-5" viewBox="0 0 300 300">
                    <circle cx="150" cy="150" r="40" stroke="currentColor" fill="none" opacity="0.4"/>
                    <circle cx="150" cy="150" r="80" stroke="currentColor" fill="none" opacity="0.4"/>
                    <circle cx="150" cy="150" r="120" stroke="currentColor" fill="none" opacity="0.4"/>
                    <path d="M150 30 L150 270" stroke="currentColor" fill="none" opacity="0.3"/>
                    <path d="M30 150 L270 150" stroke="currentColor" fill="none" opacity="0.3"/>
                    <path d="M70 70 L230 230" stroke="currentColor" fill="none" opacity="0.3"/>
                    <path d="M230 70 L70 230" stroke="currentColor" fill="none" opacity="0.3"/>
                    <circle cx="150" cy="150" r="8" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="70" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="150" cy="230" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="70" cy="150" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="230" cy="150" r="4" stroke="currentColor" fill="none"/>
                    <circle cx="100" cy="100" r="3" stroke="currentColor" fill="none"/>
                    <circle cx="200" cy="200" r="3" stroke="currentColor" fill="none"/>
                    <circle cx="100" cy="200" r="3" stroke="currentColor" fill="none"/>
                    <circle cx="200" cy="100" r="3" stroke="currentColor" fill="none"/>
                </svg>
            </div>
        </div>

        <div class="connection-lines"></div>
        <div class="grid-lines"></div>

        <!-- Hero Content -->
        <div class="hero-overlay">
            <div class="container">
                <div class="hero-content-wrapper">
                    <?php if (has_post_thumbnail()) : 
                        $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
                        $thumbnail_alt = get_post_meta(get_post_thumbnail_id($post->ID), '_wp_attachment_image_alt', true);
                    ?>
                        <div class="hero-thumbnail">
                            <div class="hero-thumbnail-inner">
                                <img src="<?php echo esc_url($thumbnail_url[0]); ?>" 
                                     alt="<?php echo esc_attr($thumbnail_alt ?: get_the_title()); ?>" 
                                     class="hero-featured-image">
                                <div class="hero-thumbnail-overlay">
                                    <i class="bi bi-arrow-right-circle-fill"></i>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="hero-text-content">
                        <div class="hero-badge">
                            <i class="bi bi-star-fill"></i> Smart Web Hosting Solutions
                        </div>
                        <h1 class="kpy-sg-title">Smart Web Hosting Solutions</h1>
                    </div>
                </div>
                
                <!-- Feature Circles - Horizontal line at bottom -->
                <div class="feature-circles-wrapper">
                    <div class="feature-circles">
                        <div class="feature-circle"><i class="bi bi-check-circle-fill"></i><span>99.99% Uptime</span></div>
                        <div class="feature-circle"><i class="bi bi-envelope-fill"></i><span>Email Service</span></div>
                        <div class="feature-circle"><i class="bi bi-shield-lock-fill"></i><span>Free SSL</span></div>
                        <div class="feature-circle"><i class="bi bi-graph-up"></i><span>Best Price</span></div>
                        <div class="feature-circle"><i class="bi bi-headset"></i><span>24/7 Support</span></div>
                        <div class="feature-circle"><i class="bi bi-wordpress"></i><span>WP Ready</span></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section class="pricing-section">
        <div class="container">
            <div class="kpy-sg-header">
            <div class="kpy-sg-title-container">
                <div class="kpy-sg-title-bg" aria-hidden="true">
                    Real Uptime Experience
                </div>

                <!-- MAIN TITLE -->
                <h2 class="kpy-sg-title">
                    <span class="kpy-sg-title-red">Our</span>
                    <span class="kpy-sg-title-white">Packages</span>
                </h2>
            </div>
        </div>
            
            <div class="pricing-grid">
                <!-- BRONZE Plan -->
                <div class="pricing-card bronze">
                    <div class="pricing-badge">BRONZE</div>
                    <div class="pricing-type">Web Hosting</div>
                    <div class="pricing-note">The cost is Exclusive of Taxes.</div>
                    <div class="pricing-price">UGX25,000<span>/mo</span></div>
                    <ul class="pricing-features">
                        <li><i class="bi bi-hdd-stack"></i> 3,500MB Disk Space</li>
                        <li><i class="bi bi-wifi"></i> 25,000MB Bandwidth</li>
                        <li><i class="bi bi-sliders2"></i> Easy Control Panel</li>
                        <li><i class="bi bi-envelope"></i> 45 Email Accounts</li>
                        <li><i class="bi bi-database"></i> 45 Databases</li>
                        <li><i class="bi bi-plus-circle"></i> 2 Add Domains</li>
                        <li><i class="bi bi-headset"></i> Free on Email & Call Support</li>
                    </ul>
                    <a href="#" class="pricing-btn">Get Started</a>
                </div>

                <!-- SILVER Plan -->
                <div class="pricing-card silver">
                    <div class="pricing-badge">SILVER</div>
                    <div class="pricing-type">Web Hosting</div>
                    <div class="pricing-note">The cost is Exclusive of Taxes.</div>
                    <div class="pricing-price">UGX51,100<span>/mo</span></div>
                    <ul class="pricing-features">
                        <li><i class="bi bi-hdd-stack"></i> 15,000MB Disk Space</li>
                        <li><i class="bi bi-wifi"></i> 80,000MB Bandwidth</li>
                        <li><i class="bi bi-sliders2"></i> Easy Control Panel</li>
                        <li><i class="bi bi-envelope"></i> 250 Email Accounts</li>
                        <li><i class="bi bi-database"></i> 150 Databases</li>
                        <li><i class="bi bi-plus-circle"></i> 3 Add Domains</li>
                        <li><i class="bi bi-headset"></i> Free on Email & Call Support</li>
                    </ul>
                    <a href="#" class="pricing-btn">Get Started</a>
                </div>

                <!-- GOLD Plan -->
                <div class="pricing-card gold featured">
                    <div class="popular-tag">MOST POPULAR</div>
                    <div class="pricing-badge">GOLD</div>
                    <div class="pricing-type">Web Hosting</div>
                    <div class="pricing-note">The cost is Exclusive of Taxes.</div>
                    <div class="pricing-price">UGX78,120<span>/mo</span></div>
                    <ul class="pricing-features">
                        <li><i class="bi bi-hdd-stack"></i> 45,000MB Disk Space</li>
                        <li><i class="bi bi-wifi"></i> 100,000MB Bandwidth</li>
                        <li><i class="bi bi-sliders2"></i> Easy Control Panel</li>
                        <li><i class="bi bi-envelope"></i> Unlimited Email Accounts</li>
                        <li><i class="bi bi-database"></i> 500 Databases</li>
                        <li><i class="bi bi-headset"></i> Free on Email & Call Support</li>
                        <li><i class="bi bi-gift"></i> 1 Free domain name (.com, .org, .net)</li>
                    </ul>
                    <a href="#" class="pricing-btn">Get Started</a>
                </div>

                <!-- PLATINUM Plan -->
                <div class="pricing-card platinum">
                    <div class="pricing-badge">PLATINUM</div>
                    <div class="pricing-type">Web Hosting</div>
                    <div class="pricing-note">The cost is Exclusive of Taxes.</div>
                    <div class="pricing-price">UGX140,000<span>/mo</span></div>
                    <ul class="pricing-features">
                        <li><i class="bi bi-hdd-stack"></i> 75,000MB Disk Space</li>
                        <li><i class="bi bi-wifi"></i> 200,000MB Bandwidth</li>
                        <li><i class="bi bi-sliders2"></i> Easy Control Panel</li>
                        <li><i class="bi bi-envelope"></i> Unlimited Email Accounts</li>
                        <li><i class="bi bi-database"></i> 500 Databases</li>
                        <li><i class="bi bi-headset"></i> Free on Email & Call Support</li>
                        <li><i class="bi bi-gift"></i> 2 Free domain names (.com, .org, .net)</li>
                    </ul>
                    <a href="#" class="pricing-btn">Get Started</a>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQs Section -->
    <section class="faqs-section">
        <div class="container">
            <div class="kpy-sg-header">
            <div class="kpy-sg-title-container">
                <div class="kpy-sg-title-bg" aria-hidden="true">
                    Web Hosting FAQs
                </div>

                <!-- MAIN TITLE -->
                <h2 class="kpy-sg-title">
                    <span class="kpy-sg-title-red">Frequently </span>
                    <span class="kpy-sg-title-white">Asked Questions</span>
                </h2>
            </div>
            
            <div class="faqs-grid">
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What is web hosting and why do I need it?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Web hosting is a service that allows you to publish your website on the internet. It provides the server space and technologies needed to make your website accessible to visitors worldwide. Without web hosting, your website cannot be viewed online.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What is the difference between shared hosting and VPS hosting?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Shared hosting means your website shares server resources with other websites, making it more affordable for small to medium sites. VPS (Virtual Private Server) hosting gives you dedicated resources and more control, ideal for growing businesses that need better performance and security.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Can I upgrade my hosting plan later?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, absolutely! You can upgrade your hosting plan at any time as your business grows. Our team will help you migrate seamlessly with zero downtime, ensuring your website remains accessible throughout the upgrade process.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Do you offer a money-back guarantee?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, we offer a 30-day money-back guarantee on all our hosting plans. If you're not completely satisfied with our service within the first 30 days, we'll refund your payment in full, no questions asked.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>What kind of support do you provide?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>We provide 24/7/365 technical support via email, live chat, and phone. Our expert support team is always ready to help you with any issues, from basic setup to advanced server configurations.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="bi bi-question-circle-fill"></i>
                        <span>Is SSL certificate included in the hosting plans?</span>
                        <i class="bi bi-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, all our hosting plans come with free SSL certificates. This ensures your website is secure and encrypted, building trust with your visitors and improving your search engine rankings.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>

<script>
// FAQ Accordion Functionality
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            item.classList.toggle('active');
        });
    });
});
</script>